#define POSN_EACH_DIRECTION 10

#define MAX_COLOURS 5
enum
{
		red=0, 
		brown=1,
		blue=2,
		yellow=3,
		green=4,
		white=5
};
extern char *colournames[];
extern void initialise_display();
extern void close_display();
extern void update_display(int right[POSN_EACH_DIRECTION], int left[POSN_EACH_DIRECTION]);
