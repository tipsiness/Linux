#include <X11/Xlib.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include "specs.h"

XColor colours[MAX_COLOURS +1];
char *colournames [] = { "red",
"brown",
"blue",
"yellow",
"green",
"white" };

const unsigned int line_width = 2; /* l i n e width when drawing on25 s c r e e n */
unsigned int width , height; /* h e i g h t and width f o r the new27 window . */
Display* display; /* p o i n t e r to X Di s p l a y29 s t r u c t u r e . */
GC gc; /* GC ( g r a p h i c s c o n t e x t ) us ed f o r31 drawing in our window . */
Window win; /* p o i n t e r to the newly c r e a t e d33 window . */

/*
* f u n c t i o n : c r e a t e s imp l e wind ow . Cr e a t e s a window wi th a whi t e background
* in the g i v en s i z e .
* input : d i s p l a y , s i z e o f the window ( in p i x e l s ) , and l o c a t i o n o f
* the window ( in p i x e l s ) .
* output : the window ' s ID .
* no t e s : window i s c r e a t e d wi th a b l ac k border , 2 p i x e l s wide .
* the window i s a u t oma t i c a l l y mapped a f t e r i t s c r e a t i o n .
*/
Window create_simple_window( Display* display ,
int width , int height , int x, int y ) {
int screen_num = DefaultScreen(display );
int win_border_width = 2;
Window win;

/* c r e a t e a s imp l e window , as a d i r e c t c h i l d o f the s c r e e n ' s */
/* r o o t window . Use the s c r e e n ' s b l ac k and whi t e c o l o r s as */
/* the for e g round and background c o l o r s o f the window , */
/* r e s p e c t i v e l y . P l a c e the new window ' s top?l e f t c o rne r at */
/* the g i v en ' x , y ' c o o r d i n a t e s . */
win = XCreateSimpleWindow(display , RootWindow (display , screen_num ),
x, y, width , height , win_border_width ,
BlackPixel (display , screen_num ),
WhitePixel (display , screen_num ));

/* make the window a c t u a l l y appear on the s c r e e n . */
XMapWindow (display , win);

/* f l u s h a l l pending r e q u e s t s to the X s e r v e r . */
XFlush(display );

return win;
}

GC create_gc( Display* display , Window win , int reverse_video ) {
GC gc; /* handl e o f newly c r e a t e d GC. */
unsigned long valuemask = 0; /* which v a l u e s in ' v a l u e s ' to */
/* che ck when c r e a t i n g the GC. */
XGCValues values; /* i n i t i a l v a l u e s f o r the GC. */
int line_style = LineSolid; /* s t y l e f o r l i n e s drawing and */
int cap_style = CapButt; /* s t y l e o f the l i n e ' s e d j e and */
int join_style = JoinBevel; /* j o i n e d l i n e s . */
int screen_num = DefaultScreen(display );

gc = XCreateGC(display , win , valuemask , &values );
if (gc < 0) {
fprintf(stderr , "XCreateGC: \n");
}

/* a l l o c a t e for e g round and background c o l o r s f o r t h i s GC. */
if ( reverse_video) {
XSetForeground (display , gc , WhitePixel (display , screen_num ));
XSetBackground (display , gc , BlackPixel (display , screen_num ));
}
else {
XSetForeground (display , gc , BlackPixel (display , screen_num ));
XSetBackground (display , gc , WhitePixel (display , screen_num ));
}

/* d e f i n e the s t y l e o f l i n e s tha t wi l l be drawn us ing t h i s GC. */
XSetLineAttributes(display , gc ,
line_width , line_style , cap_style , join_style );

/* d e f i n e the f i l l s t y l e f o r the GC. to be ' s o l i d f i l l i n g ' . */
XSetFillStyle(display , gc , FillSolid );

return gc;
}


void initialise_display( ) {
int screen_num ; /* number o f s c r e e n to p l a c e the window on . */
unsigned int display_width ,
display_height ; /* h e i g h t and width o f the X d i s p l a y . */
char * display_name = getenv("DISPLAY"); /* a d d r e s s o f the X d i s p l a y . */
Colormap screen_colormap; /* c o l o r map to us e f o r a l l o c a t i n g c o l o r s . */
Status rc; /* r e turn s t a t u s o f v a r i o u s X l i b113 f u n c t i o n s . */
int i;

/* open c onne c t i on wi th the X s e r v e r . */
display = XOpenDisplay( display_name );
if (display == NULL) {
fprintf(stderr , "Cannot connect to X server '%s '\n", display_name );
exit (1);
}

/* g e t the geomet ry o f the d e f a u l t s c r e e n f o r our d i s p l a y . */
screen_num = DefaultScreen(display );
display_width = DisplayWidth(display , screen_num );
display_height = DisplayHeight(display , screen_num );

width = ( display_width / 2);
height = ( display_height / 6);

/* c r e a t e a s imp l e window , as a d i r e c t c h i l d o f the s c r e e n ' s */
/* r o o t window . Use the s c r e e n ' s whi t e c o l o r as the background */
/* c o l o r o f the window . P l a c e the new window ' s top?l e f t c o rne r */
/* at the g i v en ' x , y ' c o o r d i n a t e s . */
win = create_simple_window(display , width , height , 0, 0);

/* a l l o c a t e a new GC ( g r a p h i c s c o n t e x t ) f o r drawing in the window . */
gc = create_gc(display , win , 0);
XSync(display , False );

/* g e t a c c e s s to the s c r e e n ' s c o l o r map . */
screen_colormap = DefaultColormap(display , DefaultScreen(display ));

/* a l l o c a t e the s e t o f c o l o r s we wi l l want to us e f o r the drawing . */
for( i = 0; i <= MAX_COLOURS; ++i ) {
rc = XAllocNamedColor( display , screen_colormap ,
colournames[i], &colours[i], &colours[i] );
if (rc == 0) {
fprintf( stderr ," XAllocNamedColor - failed to allocated '%s' color .\n",colournames[i]);
exit (1);
}
}

/* Draw the " g r i d " o f s l o t s on the b r i d g e */
XSetForeground (display , gc , colours[brown ]. pixel );
XDrawLine(display , win , gc , 0, height /2, width , height /2);
for( i = 0; i < POSN_EACH_DIRECTION; ++i ) {
const int step = width / POSN_EACH_DIRECTION;
XDrawLine(display , win , gc , step * i, 0, step * i, height );
}
}

void close_display () {
/* c l o s e the c onne c t i on to the X s e r v e r . */
XCloseDisplay(display );
}


void update_display ( int right[ POSN_EACH_DIRECTION],
int left[ POSN_EACH_DIRECTION] ) {
int i;
for( i = 0; i < POSN_EACH_DIRECTION; ++i ) {
const int step = width / POSN_EACH_DIRECTION;
const int offset = 5;
const int carheight = (( height -line_width ) / 2) - (2 * offset );
const int carwidth = ((( width - ( POSN_EACH_DIRECTION * line_width )) /
POSN_EACH_DIRECTION) - (2 * offset ));

XSetForeground ( display , gc , colours[right[i]]. pixel );
XFillRectangle ( display , win , gc , step * i + offset , offset ,
carwidth , carheight );

XSetForeground ( display , gc , colours[left[i]]. pixel );
XFillRectangle ( display , win , gc , step * i + offset ,
offset + height / 2,
carwidth , carheight );
}

/* f l u s h a l l pending r e q u e s t s to the X s e r v e r . */
XFlush(display );
}

